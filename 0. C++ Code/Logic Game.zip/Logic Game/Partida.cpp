#include "Partida.h"

Partida::Partida()
{
    m_temps = 0;
	m_nivell = 1;
	m_velocitat = 1;
	m_puntuacio = 0;
	m_acabada = false;

	m_moviment = nullptr;
	m_figuras = nullptr;
	m_movAux = m_moviment;
	m_figAux = m_figuras;
}


void Partida::inicialitza(int mode)
{
	m_joc.setFiguraColocada(false);
	m_temps = 0;
	m_nivell = 1;
	m_velocitat = 1;
	m_puntuacio = 0;
	m_joc.setGo(false);
	m_joc.resetTauler();
	if (mode == 1)
	{
		m_joc.novaFigura();
	}
	else if (mode == 2)
	{
		m_figuras = nullptr;
		m_moviment = nullptr;
		cout << "Nom del fitxer amb l'estat inicial del tauler: ";
		string fitxerInicial;
		cin >> fitxerInicial;
		cout << "Nom del fitxer amb la sequencia de figures: ";
		string fitxerFigures;
		cin >> fitxerFigures;
		cout << "Nom del fitxer amb la sequencia de moviments: ";
		string fitxerMoviments;
		cin >> fitxerMoviments;
		m_joc.inicialitza(fitxerInicial);

		ifstream fitxer;
		fitxer.open("data/Games/" + fitxerMoviments);
		if (fitxer.is_open())
		{
			bool trobat = false;
			int input;
			TipusMoviment mov;

			fitxer >> input;
			while (!fitxer.eof())
			{
				trobat = false;
				switch (input)
				{
				case 0:
					mov = MOVIMENT_ESQUERRA;
					break;
				case 1: 
					mov = MOVIMENT_DRETA;
					break;
				case 2:
					mov = MOVIMENT_GIR_HORARI;
					break;
				case 3:
					mov = MOVIMENT_GIR_ANTI_HORARI;
					break;
				case 4:
					mov = MOVIMENT_BAIXA;
					break;
				case 5:
					mov = MOVIMENT_BAIXA_FINAL;
					break;
				}
				NodeMoviment* moviment = new NodeMoviment;
				moviment->setValor(mov);
				moviment->setNext(nullptr);

				if (m_moviment == nullptr)
					m_moviment = moviment;
				else
				{
					NodeMoviment* seguent = m_moviment;
					while (!trobat)
					{
						if (seguent->getNext() == nullptr)
						{
							trobat = true;
							seguent->setNext(moviment);
						}
						else
							seguent = seguent->getNext();
						
					}
				}
				fitxer >> input;
			}
			m_movAux = m_moviment;
			fitxer.close();
		}

		fitxer.open("data/Games/" + fitxerFigures);
		if (fitxer.is_open())
		{
			Posicio pos;
			int tipus, gir;
			fitxer >> tipus >> pos.m_y >> pos.m_x >> gir;
			bool trobat = false;
			while (!fitxer.eof())
			{
				NodeFigura* figura = new NodeFigura;
				trobat = false;
				Figura fig;

				fig.initFigura(TipusFigura(tipus));

				pos.m_x--;
				pos.m_y--;
				fig.setPos(pos);

				for (int i = 0; i < gir; i++)
					fig.girarFigura(GIR_HORARI);
				
				figura->setValor(fig);
				figura->setNext(nullptr);

				if (m_figuras == nullptr)
					m_figuras = figura;
				else
				{
					NodeFigura* seguent = m_figuras;
					while (!trobat)
					{
						if (seguent->getNext() == nullptr)
						{
							trobat = true;
							seguent->setNext(figura);
						}
						else
							seguent = seguent->getNext();
					}
				}
				fitxer >> tipus >> pos.m_x >> pos.m_y >> gir;
			}
			m_figAux = m_figuras;
			fitxer.close();
		}
	}

}

void Partida::actualitza(int mode, double deltaTime)
{
	m_joc.dibuixa();
	string msg = "SCORE: " + to_string(m_puntuacio);
	string msg2 = " LEVEL: " + to_string(m_nivell);
	GraphicManager::getInstance()->drawFont(FONT_WHITE_30, 40, 30, 0.8, msg);
	GraphicManager::getInstance()->drawFont(FONT_WHITE_30, 445, 30, 0.8, msg2);

	int filesCompletes = 0;



		if (mode == 1)
		{
			if (!m_joc.getFiguraColocada())
			{
				m_temps += deltaTime;
				if (m_temps > m_velocitat)
				{
					filesCompletes = m_joc.baixaFigura();
					m_temps = 0.0;
				}
				if (Keyboard_GetKeyTrg(KEYBOARD_UP))
					m_joc.giraFigura(GIR_HORARI);
				else if (Keyboard_GetKeyTrg(KEYBOARD_RIGHT))
					m_joc.mouFigura(1);
				else if (Keyboard_GetKeyTrg(KEYBOARD_DOWN))
					m_joc.giraFigura(GIR_ANTI_HORARI);
				else if (Keyboard_GetKeyTrg(KEYBOARD_LEFT))
					m_joc.mouFigura(-1);
				else if (Keyboard_GetKeyTrg(KEYBOARD_SPACE))
					while (!m_joc.getFiguraColocada())
						filesCompletes = m_joc.baixaFigura();
				m_puntuacio += sumarPuntuacio(filesCompletes);
			}
			else
			{
				if (m_joc.getGo() == true)
					m_acabada = true;

				if (!m_acabada) 
				{
					m_joc.novaFigura();
					m_puntuacio += 10;
					m_velocitat = 1;
					if (m_puntuacio > 1000)
						m_nivell = (m_puntuacio / 1000) + 1;
					for (int i = 0; i < m_nivell; i++)
						m_velocitat *= 0.9;

				}
				else 
				{
					m_puntuacio -= sumarPuntuacio(filesCompletes);
					m_puntuacio -= 10;
					string msg = "SCORE: " + to_string(m_puntuacio);
					string msg2 = " LEVEL: " + to_string(m_nivell);
					GraphicManager::getInstance()->drawSprite(GRAFIC_GAME_OVER, 0, 0, false);
				}
			}
		}
		else if (mode == 2)
		{
			filesCompletes = 0;
			m_temps += deltaTime;
			if (m_temps > m_velocitat)
			{
				m_temps = 0.0;
				if (m_movAux != nullptr)
				{
					TipusMoviment mov = m_movAux->getValor();
					m_movAux = m_movAux->getNext();
					switch (mov)
					{
					case MOVIMENT_ESQUERRA:
						m_joc.mouFigura(-1);
						break;
					case MOVIMENT_DRETA:
						m_joc.mouFigura(1);
						break;
					case MOVIMENT_GIR_HORARI:
						m_joc.giraFigura(GIR_HORARI);
						break;
					case MOVIMENT_GIR_ANTI_HORARI:
						m_joc.giraFigura(GIR_ANTI_HORARI);
						break;
					case MOVIMENT_BAIXA:
						filesCompletes = m_joc.baixaFigura();
						break;
					case MOVIMENT_BAIXA_FINAL:
						while (!m_joc.getFiguraColocada())
							filesCompletes = m_joc.baixaFigura();
						break;
						m_puntuacio += sumarPuntuacio(filesCompletes);
					}
					if (m_joc.getFiguraColocada())
					{
						m_joc.setFigura(m_figAux->getValor());
						m_figAux->setNext(m_figAux->getNext());
						m_joc.setFiguraColocada(false);
						m_puntuacio += 10;
					}
				}
				else
				{
					m_acabada = true;
					GraphicManager::getInstance()->drawSprite(GRAFIC_GAME_OVER, 0, 0, false);
				}
			}
		}
	}


int Partida::sumarPuntuacio(int nFilesCompletades)
{
	int puntuacio = 0;

	switch (nFilesCompletades)
	{
	case 1:
		puntuacio += 100;
		break;
	case 2:
		puntuacio += 150;
		break;
	case 3:
		puntuacio += 175;
		break;
	case 4:
		puntuacio += 200;
		break;
	default:
		break;
	}
	return puntuacio;

}
