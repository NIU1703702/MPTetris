#include "Joc.h"
#include <cstdlib>


void Joc::inicialitza(const string& nomFitxerInicial) //incializa el juego
{
	ifstream fitxer;
	Posicio pos;
	int gir, input;
	m_figuraColocada = false;

		fitxer.open("data/Games/" + nomFitxerInicial);
		if (fitxer.is_open())
		{
			fitxer >> input >> pos.m_y >> pos.m_x >> gir;
			pos.m_x--;
			pos.m_y--;
			m_figura.initFigura(TipusFigura(input));
			m_figura.setPos(pos);
			m_pos = pos;
			for (int i = 0; i < gir; i++)
				m_figura.girarFigura(GIR_HORARI);

			for (int i = 0; i < MAX_COL; i++)
			{
				for (int j = 0; j < MAX_FILA; j++)
				{
					int color;
					fitxer >> color;

					m_tauler.setTauler(ColorFigura(color), i, j);
				}
			}
			fitxer.close();
		}	
}

bool Joc::giraFigura(DireccioGir direccio)
{
	bool potGirar = true;
	m_figura.girarFigura(direccio);

	if (!m_tauler.validMoviments(m_figura, m_pos))
	{
		if (direccio == GIR_HORARI)
			m_figura.girarFigura(GIR_ANTI_HORARI);
		else
			m_figura.girarFigura(GIR_HORARI);
		potGirar = false;
	}

	return potGirar;
}

bool Joc::mouFigura(int dirX)
{
	bool moviment = true;
	m_figura.desplacamentFigura(dirX); //lo mueve y despues comprueba si es correcto

	if (!m_tauler.validMoviments(m_figura, m_figura.getPosicio())) //si no es correcto
	{
		if (dirX == -1)
			m_figura.desplacamentFigura(1); //retrocede
		else
			m_figura.desplacamentFigura(-1); //retrocede
		moviment = false;
	}
	else
		m_pos = m_figura.getPosicio(); //se puede mover por lo tanto se coloca (ya se habia movido)

	return moviment;
}

int Joc::baixaFigura()
{
	int eliminades = 0;
	m_figura.baixaFigura(1); //baja la figura y despues comprueba si es correcto

	if (!m_tauler.validMoviments(m_figura, m_figura.getPosicio())) //si no es correcto
	{
		m_figura.baixaFigura(-1); //retrocede
		m_tauler.colocarFigura(m_figura, m_figura.getPosicio()); //lo coloca porque ya no puede bajar mas
		m_figuraColocada = true;
		eliminades = m_tauler.eliminaFila(); //comprobamos y eliminamos, si hay, las filas completas
	}
	else
		m_pos = m_figura.getPosicio();  //si ha podido bajar, recupera esa posicion y la guarda

	return eliminades;
}

void Joc::escriuTauler(const string& nomFitxer)
{
	int i, j;
	ofstream fitxer;

	fitxer.open(nomFitxer);

	if (fitxer.is_open())
	{
		if (!m_figuraColocada)
			m_tauler.colocarFigura(m_figura, m_pos);

		for (int i = 0; i < MAX_COL; i++)
		{
			for (int j = 0; j < MAX_FILA; j++)
				fitxer << int(m_tauler.getTauler(i, j)) << " ";
			fitxer << endl;
		}

		fitxer.close();
	}
}

void Joc::dibuixa()
{
	m_tauler.dibuixa();
	m_figura.dibuixa();
}

void Joc::novaFigura()
{
	Posicio pos;

	int count = 0;

		do
		{
			int tipus = (rand() % 7) + 1;
			m_figura.initFigura(TipusFigura(tipus));
			pos.m_y = 0;
			pos.m_x = rand() % MAX_FILA;
			m_figura.setPos(pos);

			if (count < 30)
				count++;
			else
				m_go = true;
				
		} while (!m_tauler.validMoviments(m_figura, pos) && !m_go);

	m_figuraColocada = false;

}

void Joc::resetTauler()
{
	for (int i = 0; i < MAX_COL; i++)
		for (int j = 0; j < MAX_FILA; j++)
			m_tauler.setTauler(COLOR_NEGRE, i, j);
}

bool Joc::potBaixar() {

	if (!m_tauler.validMoviments(m_figura, m_figura.getPosicio())) {
		return false;
	}
	else {
		return true;
	}

}